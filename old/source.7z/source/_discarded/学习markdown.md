title: 学习markdown
author: ki9mu
abbrlink: 6b72cdb5
date: 2019-03-23 16:29:10
tags:
---
# 1级标题
##### 5级标题

## 无序列表1
* 1
* 2
* 3

## 无序列表2
- 1 
- 2
- 3

## 有序列表
2. aaaa
1. bbbb
1. cccc
5. 当有序列表的顺序不一样时会自动修改，只看第一个，然后递增

> 引用

## 链接
[ki9mu's blog](https://ki9mu.github.io)

## 图片链接
![miku的图片](http://img.netbian.com/file/2018/0223/69f8d5aefbe93d9403e0e7dab77d107f.jpg)

**粗体

*斜体